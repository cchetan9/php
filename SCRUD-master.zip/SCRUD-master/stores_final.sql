-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 03, 2019 at 11:43 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpscrud`
--

-- --------------------------------------------------------

--
-- Table structure for table `it_companies`
--

CREATE TABLE `it_companies` (
  `company_id` int(11) UNSIGNED NOT NULL,
  `rank` int(11) UNSIGNED NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `industries` varchar(255) NOT NULL,
  `revenue` float(9,2) NOT NULL,
  `fiscal_year` year(4) NOT NULL,
  `employees` int(11) UNSIGNED NOT NULL,
  `market_cap` float(9,2) NOT NULL,
  `headquarters` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `it_companies`
--

INSERT INTO `it_companies` (`company_id`, `rank`, `company_name`, `industries`, `revenue`, `fiscal_year`, `employees`, `market_cap`, `headquarters`) VALUES
(1, 1, 'Samsung Electronics', 'Mobile Devices', 212.68, 2013, 326000, 137.91, 'Seoul, South Korea'),
(2, 2, 'Apple Inc.', 'Personal Computing', 182.79, 2014, 98000, 616.59, 'Cupertino, CA, USA (Silicon Valley)'),
(3, 3, 'Foxconn', 'OEM Component Manufacturing', 132.07, 2013, 1290000, 32.15, 'New Taipei, Taiwan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `it_companies`
--
ALTER TABLE `it_companies`
  ADD PRIMARY KEY (`company_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `it_companies`
--
ALTER TABLE `it_companies`
  MODIFY `company_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
