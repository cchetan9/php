<?php
require 'aws-autoloader.php';
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

$filepath = 'About_Us 2.jpg';
// Set Amazon s3 credentials

$client = new Aws\S3\S3Client([
    'version'     => 'latest',
    'region'      => 'ap-south-1',
    'credentials' => [
        'key'    => 'AKIAJ2TNOZU4EZGRRJHA',
        'secret' => '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'
    ]
]);

try {
  $client->putObject(array(
    'Bucket'=>'banana-it-file',
    'Key' =>  'abount_us_1.jpg',
    'SourceFile' => $filepath,
    'ACL'        => 'public-read',
    'StorageClass' => 'REDUCED_REDUNDANCY'
    
  ));
  
  echo "File uploaded Successfully...";

} catch (S3Exception $e) {
  // Catch an S3 specific exception.
  echo $e->getMessage();
}


?>
