<?php
require 'aws-autoloader.php';
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

$filepath = 'About_Us 2.jpg';
// Set Amazon s3 credentials

$client = new Aws\S3\S3Client([
    'version'     => 'latest',
    'region'      => 'ap-south-1',
    'credentials' => [
        'key'    => 'AKIAJ2TNOZU4EZGRRJHA',
        'secret' => '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'
    ]
]);

try {
    $result = $client->getObject([
      'Bucket'=>'banana-it-file',
      'Key' =>'abount_us.jpg'
    ]);

    // Display the object in the browser.
    
    $filepath = $result['@metadata']['effectiveUri'];
    header('Content-Type: application/octet-stream');
    header("Content-Transfer-Encoding: Binary"); 
    header("Content-disposition: attachment; filename=\"".$filepath."\"");     
    readfile($filepath);
    
    echo "File Downloaded..";
   

} catch (S3Exception $e) {
  // Catch an S3 specific exception.
  echo $e->getMessage();
}


?>
