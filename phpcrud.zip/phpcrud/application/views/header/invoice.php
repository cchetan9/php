<!-- Invoice CSS  -->
<link href="<?php echo base_url('assets/invoice/style.css') ?>" rel="stylesheet" media="screen">
<link href="<?php echo base_url('assets/invoice/print.css') ?>" rel="stylesheet" media="print"> 