<!-- Barcode Print CSS  -->
<link href="<?php echo base_url('assets/css/barcode.css') ?>" rel="stylesheet" media="print">