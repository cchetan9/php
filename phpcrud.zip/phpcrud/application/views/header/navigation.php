<nav class="nav">
    <ul>
        
        <li><a href="<?php echo base_url('index.php/items'); ?>"><i class="fa fa-smile-o fa-2x"></i><br/>Item List</a></li>
        <li><a href="<?php echo base_url('index.php/login/logout'); ?>"><i class="fa fa-sign-out fa-2x"></i><br/>Logout</a></li>
    </ul>
</nav>